// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "account": MessageLookupByLibrary.simpleMessage("Account"),
        "add": MessageLookupByLibrary.simpleMessage("Add"),
        "addBook": MessageLookupByLibrary.simpleMessage("Add Book"),
        "addGenre": MessageLookupByLibrary.simpleMessage("Add Genre"),
        "allGenres": MessageLookupByLibrary.simpleMessage("All Genres"),
        "alreadyInDb": MessageLookupByLibrary.simpleMessage("Already in DB"),
        "anyUnsavedChangesWillBeLost": MessageLookupByLibrary.simpleMessage(
            "Any unsaved changes will be lost."),
        "areYouSureYouWantToLogOut": MessageLookupByLibrary.simpleMessage(
            "Are you sure you want to log out?"),
        "australia": MessageLookupByLibrary.simpleMessage("Australia"),
        "author": MessageLookupByLibrary.simpleMessage("Author"),
        "basedOnCollectedReaderData": MessageLookupByLibrary.simpleMessage(
            "Based on Collected Reader Data"),
        "basedOnYour": MessageLookupByLibrary.simpleMessage(
            "Based on your scores, here are universities tailored just for you. Start exploring your future today!"),
        "bookDescription": MessageLookupByLibrary.simpleMessage(
            "This fantasy epic has surged in popularity. especially among readers who enjoy immersive world-building and richly developed characters. Recent activity shows a spike in holds and requests for this title."),
        "bookDetails": MessageLookupByLibrary.simpleMessage("Book Details"),
        "booksToStock": MessageLookupByLibrary.simpleMessage("Books to Stock"),
        "browseTheListOfBooksCurrentlyInYourDatabase":
            MessageLookupByLibrary.simpleMessage(
                "Browse the list of books currently in your database"),
        "budgetRange": MessageLookupByLibrary.simpleMessage("Budget Range"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancel"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Change Password"),
        "chooseYourLanguage":
            MessageLookupByLibrary.simpleMessage("Choose Your Language"),
        "close": MessageLookupByLibrary.simpleMessage("Close"),
        "compareScores": MessageLookupByLibrary.simpleMessage("Compare Scores"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirm Password"),
        "countryPreferences":
            MessageLookupByLibrary.simpleMessage("Country Preferences"),
        "delete": MessageLookupByLibrary.simpleMessage("Delete"),
        "deleteBooks": MessageLookupByLibrary.simpleMessage("Delete Books"),
        "didntReceiveCode":
            MessageLookupByLibrary.simpleMessage("Didnt receive code?"),
        "dob": MessageLookupByLibrary.simpleMessage("DOB - 1999/08/15"),
        "done": MessageLookupByLibrary.simpleMessage("Done"),
        "dontHaveAnAccount":
            MessageLookupByLibrary.simpleMessage("Dont have an account?"),
        "editProfile": MessageLookupByLibrary.simpleMessage("Edit Profile"),
        "eight_to_nine": MessageLookupByLibrary.simpleMessage("8.0 - 9.0"),
        "eighty_to_hundred": MessageLookupByLibrary.simpleMessage("80 - 100"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "enterAuthorsName":
            MessageLookupByLibrary.simpleMessage("Enter Author\'s Name"),
        "enterBookTitle":
            MessageLookupByLibrary.simpleMessage("Enter Book Title"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Enter your phone number"),
        "fantasy": MessageLookupByLibrary.simpleMessage("Fantasy"),
        "features": MessageLookupByLibrary.simpleMessage("Features"),
        "fieldOfStudy": MessageLookupByLibrary.simpleMessage("Field of Study"),
        "findByGMATScore":
            MessageLookupByLibrary.simpleMessage("Find by GMAT \n Score only"),
        "findByGREScore":
            MessageLookupByLibrary.simpleMessage("Find by GRE \n Score only"),
        "findByIELTSScore":
            MessageLookupByLibrary.simpleMessage("Find by IELTS \n Score only"),
        "findByTOEFLScore":
            MessageLookupByLibrary.simpleMessage("Find by TOEFL \n Score only"),
        "findTopUniversities":
            MessageLookupByLibrary.simpleMessage("Find Top\nUniversities"),
        "findYourFavouriteUniversity": MessageLookupByLibrary.simpleMessage(
            "FIND YOUR FAVOURITE UNIVERSITY"),
        "findYourPerfectUniversityBasedOnYourScores":
            MessageLookupByLibrary.simpleMessage(
                "Find Your Perfect University Based on Your Scores"),
        "firstName": MessageLookupByLibrary.simpleMessage("First Name"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Forgot Password?"),
        "four_hundred_fifty_to_six_hundred":
            MessageLookupByLibrary.simpleMessage("450 - 600"),
        "genre": MessageLookupByLibrary.simpleMessage("Genre"),
        "germany": MessageLookupByLibrary.simpleMessage("Germany"),
        "getStarted": MessageLookupByLibrary.simpleMessage("Get Started"),
        "gpa": MessageLookupByLibrary.simpleMessage("GPA"),
        "graduate": MessageLookupByLibrary.simpleMessage("Graduate"),
        "haveYouGivenGMATBefore":
            MessageLookupByLibrary.simpleMessage("Have you given GMAT before?"),
        "haveYouGivenGREBefore":
            MessageLookupByLibrary.simpleMessage("Have you given GRE before?"),
        "haveYouGivenIELTSBefore": MessageLookupByLibrary.simpleMessage(
            "Have you given IELTS before?"),
        "haveYouGivenTOEFLBefore": MessageLookupByLibrary.simpleMessage(
            "Have you given TOEFL before?"),
        "hello": MessageLookupByLibrary.simpleMessage("Hello"),
        "help": MessageLookupByLibrary.simpleMessage("Help"),
        "history": MessageLookupByLibrary.simpleMessage("History"),
        "home": MessageLookupByLibrary.simpleMessage("Home"),
        "hundred_to_one_twenty":
            MessageLookupByLibrary.simpleMessage("100 - 120"),
        "ieltsScore": MessageLookupByLibrary.simpleMessage("IELTS Score"),
        "inStock": MessageLookupByLibrary.simpleMessage("In Stock"),
        "inputYourGMATScore":
            MessageLookupByLibrary.simpleMessage("Input your GMAT score"),
        "inputYourGREScore":
            MessageLookupByLibrary.simpleMessage("Input your GRE score"),
        "inputYourIELTSScore":
            MessageLookupByLibrary.simpleMessage("Input your IELTS score"),
        "inputYourPreferredLocation": MessageLookupByLibrary.simpleMessage(
            "Input your preferred location"),
        "inputYourTOEFLScore":
            MessageLookupByLibrary.simpleMessage("Input your TOEFL score"),
        "lastName": MessageLookupByLibrary.simpleMessage("Last Name"),
        "libraryDatabase":
            MessageLookupByLibrary.simpleMessage("Library Database"),
        "libraryPulse": MessageLookupByLibrary.simpleMessage("Library Pulse"),
        "location": MessageLookupByLibrary.simpleMessage("Location"),
        "logOut": MessageLookupByLibrary.simpleMessage("Log out"),
        "login": MessageLookupByLibrary.simpleMessage("Login"),
        "loginFailed": MessageLookupByLibrary.simpleMessage(
            "Login failed. Please try again."),
        "loginToYourAccount":
            MessageLookupByLibrary.simpleMessage("Login to your account!"),
        "name": MessageLookupByLibrary.simpleMessage("Name"),
        "next": MessageLookupByLibrary.simpleMessage("Next"),
        "no": MessageLookupByLibrary.simpleMessage("No"),
        "password": MessageLookupByLibrary.simpleMessage("Password"),
        "passwordAndConfirmPasswordDoNotMatch":
            MessageLookupByLibrary.simpleMessage(
                "Password and confirm password do not match"),
        "patrickRothfus":
            MessageLookupByLibrary.simpleMessage("Patrick Rothfus"),
        "phd": MessageLookupByLibrary.simpleMessage("PhD"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("Phone number"),
        "pleaseCheckYourEmail":
            MessageLookupByLibrary.simpleMessage("Please Check Your Email!"),
        "pleaseEnterValidDOB":
            MessageLookupByLibrary.simpleMessage("Please enter valid DOB"),
        "pleaseEnterValidEmail":
            MessageLookupByLibrary.simpleMessage("Please enter valid email"),
        "pleaseEnterValidLocation":
            MessageLookupByLibrary.simpleMessage("Please Enter Valid Location"),
        "pleaseEnterValidName":
            MessageLookupByLibrary.simpleMessage("Please enter valid name"),
        "pleaseEnterValidPassword":
            MessageLookupByLibrary.simpleMessage("Please enter valid Password"),
        "pleaseEnterValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Please enter valid phone number"),
        "preferredStudyLevel":
            MessageLookupByLibrary.simpleMessage("Preferred Study Level"),
        "profile": MessageLookupByLibrary.simpleMessage("Profile"),
        "profileInformation":
            MessageLookupByLibrary.simpleMessage("Profile Information"),
        "readiculous": MessageLookupByLibrary.simpleMessage("READICULOUS"),
        "register": MessageLookupByLibrary.simpleMessage("Register"),
        "registerAccount":
            MessageLookupByLibrary.simpleMessage("Register Account"),
        "rememberMeNextTime":
            MessageLookupByLibrary.simpleMessage("Remember me next time?"),
        "requestAgain": MessageLookupByLibrary.simpleMessage("Request again"),
        "save": MessageLookupByLibrary.simpleMessage("Save"),
        "search": MessageLookupByLibrary.simpleMessage("Search"),
        "select": MessageLookupByLibrary.simpleMessage("Select"),
        "sendCode": MessageLookupByLibrary.simpleMessage("Send Code"),
        "settings": MessageLookupByLibrary.simpleMessage("Settings"),
        "seven_hundred_to_hundred":
            MessageLookupByLibrary.simpleMessage("700 - 800"),
        "seven_to_eight": MessageLookupByLibrary.simpleMessage("7.0 - 7.9"),
        "shareYourScores": MessageLookupByLibrary.simpleMessage(
            "Share your scores and preferences, and we will match you with universities that fit your goals. Your dream starts here!"),
        "signIn": MessageLookupByLibrary.simpleMessage("Sign In"),
        "signUp": MessageLookupByLibrary.simpleMessage("Sign Up"),
        "six_hundered_to_seven_hundred":
            MessageLookupByLibrary.simpleMessage("600 - 700"),
        "six_or_below": MessageLookupByLibrary.simpleMessage("6.0 or below"),
        "six_to_seven": MessageLookupByLibrary.simpleMessage("6.0 - 6.9"),
        "sixty_to_eighty": MessageLookupByLibrary.simpleMessage("60 - 80"),
        "termsAndConditions":
            MessageLookupByLibrary.simpleMessage("Terms and Conditions"),
        "theNameOfTheWind":
            MessageLookupByLibrary.simpleMessage("The Name of the Wind"),
        "three_hundred_to_three_hundred_nineteen":
            MessageLookupByLibrary.simpleMessage("300 - 319"),
        "three_twenty_to_three_forty":
            MessageLookupByLibrary.simpleMessage("320 - 340"),
        "title": MessageLookupByLibrary.simpleMessage("Title"),
        "trendingGenres":
            MessageLookupByLibrary.simpleMessage("Trending Genres"),
        "two_sixty_to_three_hundred":
            MessageLookupByLibrary.simpleMessage("260 - 300"),
        "typeYourScore":
            MessageLookupByLibrary.simpleMessage("Type your score"),
        "uk": MessageLookupByLibrary.simpleMessage("UK"),
        "undergraduate": MessageLookupByLibrary.simpleMessage("Undergraduate"),
        "uniquest": MessageLookupByLibrary.simpleMessage("UNIQUEST"),
        "universityFinder":
            MessageLookupByLibrary.simpleMessage("University Finder"),
        "usa": MessageLookupByLibrary.simpleMessage("USA"),
        "user": MessageLookupByLibrary.simpleMessage("User"),
        "username": MessageLookupByLibrary.simpleMessage("Username"),
        "verify": MessageLookupByLibrary.simpleMessage("Verify"),
        "viewDatabase": MessageLookupByLibrary.simpleMessage("View Database"),
        "welcomeBack": MessageLookupByLibrary.simpleMessage("Welcome Back"),
        "welcomeMessage":
            MessageLookupByLibrary.simpleMessage("Welcome Message"),
        "whatAreYourGMATScores":
            MessageLookupByLibrary.simpleMessage("What are your GMAT scores?"),
        "whatAreYourGREScores":
            MessageLookupByLibrary.simpleMessage("What are your GRE scores?"),
        "whatAreYourIELTSScore":
            MessageLookupByLibrary.simpleMessage("What are your IELTS score?"),
        "whatAreYourTOEFLScores":
            MessageLookupByLibrary.simpleMessage("What are your TOEFL scores?"),
        "whatIsYourApproximateBudgetForTuitionAndLivingExpenses":
            MessageLookupByLibrary.simpleMessage(
                "What is your approximate budget for tuition and living expenses?"),
        "whatIsYourGPAOrPercentageScoreFromPreviousStudies":
            MessageLookupByLibrary.simpleMessage(
                "What is your GPA or percentage score from previous studies?"),
        "whatIsYourIntendedMajorOrProgramOfInterest":
            MessageLookupByLibrary.simpleMessage(
                "What is your intended major or program of interest?"),
        "whatIsYourPreferredLevelOfStudy": MessageLookupByLibrary.simpleMessage(
            "What is your preferred level of study?"),
        "whatReadersWant": MessageLookupByLibrary.simpleMessage(
            "What readers nearby want right now"),
        "whichCountriesDoYouPreferToStudyIn":
            MessageLookupByLibrary.simpleMessage(
                "Which countries do you prefer to study in?"),
        "whyItIsRecommended":
            MessageLookupByLibrary.simpleMessage("Why It\'s recommended"),
        "wishlistedUniversities":
            MessageLookupByLibrary.simpleMessage("Wishlisted \nUniversities"),
        "yes": MessageLookupByLibrary.simpleMessage("Yes"),
        "yourCodeWasSentToYouViaEmail": MessageLookupByLibrary.simpleMessage(
            "Your code was sent to you via email"),
        "yourJourneyToFindPerfectUniversity":
            MessageLookupByLibrary.simpleMessage(
                "Your Journey to Find Perfect University"),
        "yourPasswordHasBeenSuccessfullyChanged":
            MessageLookupByLibrary.simpleMessage(
                "Your Password Has Been Successfully Changed")
      };
}
