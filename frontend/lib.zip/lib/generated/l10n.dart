// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `READICULOUS`
  String get readiculous {
    return Intl.message(
      'READICULOUS',
      name: 'readiculous',
      desc: '',
      args: [],
    );
  }

  /// `UNIQUEST`
  String get uniquest {
    return Intl.message(
      'UNIQUEST',
      name: 'uniquest',
      desc: '',
      args: [],
    );
  }

  /// `Your Journey to Find Perfect University`
  String get yourJourneyToFindPerfectUniversity {
    return Intl.message(
      'Your Journey to Find Perfect University',
      name: 'yourJourneyToFindPerfectUniversity',
      desc: '',
      args: [],
    );
  }

  /// `Sign Up`
  String get signUp {
    return Intl.message(
      'Sign Up',
      name: 'signUp',
      desc: '',
      args: [],
    );
  }

  /// `Sign In`
  String get signIn {
    return Intl.message(
      'Sign In',
      name: 'signIn',
      desc: '',
      args: [],
    );
  }

  /// `Dont have an account?`
  String get dontHaveAnAccount {
    return Intl.message(
      'Dont have an account?',
      name: 'dontHaveAnAccount',
      desc: '',
      args: [],
    );
  }

  /// `Welcome Back`
  String get welcomeBack {
    return Intl.message(
      'Welcome Back',
      name: 'welcomeBack',
      desc: '',
      args: [],
    );
  }

  /// `Login to your account!`
  String get loginToYourAccount {
    return Intl.message(
      'Login to your account!',
      name: 'loginToYourAccount',
      desc: '',
      args: [],
    );
  }

  /// `Username`
  String get username {
    return Intl.message(
      'Username',
      name: 'username',
      desc: '',
      args: [],
    );
  }

  /// `Remember me next time?`
  String get rememberMeNextTime {
    return Intl.message(
      'Remember me next time?',
      name: 'rememberMeNextTime',
      desc: '',
      args: [],
    );
  }

  /// `Forgot Password?`
  String get forgotPassword {
    return Intl.message(
      'Forgot Password?',
      name: 'forgotPassword',
      desc: '',
      args: [],
    );
  }

  /// `Phone number`
  String get phoneNumber {
    return Intl.message(
      'Phone number',
      name: 'phoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `Enter your phone number`
  String get enterYourPhoneNumber {
    return Intl.message(
      'Enter your phone number',
      name: 'enterYourPhoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `Send Code`
  String get sendCode {
    return Intl.message(
      'Send Code',
      name: 'sendCode',
      desc: '',
      args: [],
    );
  }

  /// `Please Check Your Email!`
  String get pleaseCheckYourEmail {
    return Intl.message(
      'Please Check Your Email!',
      name: 'pleaseCheckYourEmail',
      desc: '',
      args: [],
    );
  }

  /// `Verify`
  String get verify {
    return Intl.message(
      'Verify',
      name: 'verify',
      desc: '',
      args: [],
    );
  }

  /// `Your code was sent to you via email`
  String get yourCodeWasSentToYouViaEmail {
    return Intl.message(
      'Your code was sent to you via email',
      name: 'yourCodeWasSentToYouViaEmail',
      desc: '',
      args: [],
    );
  }

  /// `Didnt receive code?`
  String get didntReceiveCode {
    return Intl.message(
      'Didnt receive code?',
      name: 'didntReceiveCode',
      desc: '',
      args: [],
    );
  }

  /// `Request again`
  String get requestAgain {
    return Intl.message(
      'Request again',
      name: 'requestAgain',
      desc: '',
      args: [],
    );
  }

  /// `Your Password Has Been Successfully Changed`
  String get yourPasswordHasBeenSuccessfullyChanged {
    return Intl.message(
      'Your Password Has Been Successfully Changed',
      name: 'yourPasswordHasBeenSuccessfullyChanged',
      desc: '',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message(
      'Login',
      name: 'login',
      desc: '',
      args: [],
    );
  }

  /// `Choose Your Language`
  String get chooseYourLanguage {
    return Intl.message(
      'Choose Your Language',
      name: 'chooseYourLanguage',
      desc: '',
      args: [],
    );
  }

  /// `Select`
  String get select {
    return Intl.message(
      'Select',
      name: 'select',
      desc: '',
      args: [],
    );
  }

  /// `Register`
  String get register {
    return Intl.message(
      'Register',
      name: 'register',
      desc: '',
      args: [],
    );
  }

  /// `Email`
  String get email {
    return Intl.message(
      'Email',
      name: 'email',
      desc: '',
      args: [],
    );
  }

  /// `Name`
  String get name {
    return Intl.message(
      'Name',
      name: 'name',
      desc: '',
      args: [],
    );
  }

  /// `DOB - 1999/08/15`
  String get dob {
    return Intl.message(
      'DOB - 1999/08/15',
      name: 'dob',
      desc: '',
      args: [],
    );
  }

  /// `Password`
  String get password {
    return Intl.message(
      'Password',
      name: 'password',
      desc: '',
      args: [],
    );
  }

  /// `Confirm Password`
  String get confirmPassword {
    return Intl.message(
      'Confirm Password',
      name: 'confirmPassword',
      desc: '',
      args: [],
    );
  }

  /// `Terms and Conditions`
  String get termsAndConditions {
    return Intl.message(
      'Terms and Conditions',
      name: 'termsAndConditions',
      desc: '',
      args: [],
    );
  }

  /// `University Finder`
  String get universityFinder {
    return Intl.message(
      'University Finder',
      name: 'universityFinder',
      desc: '',
      args: [],
    );
  }

  /// `Find Your Perfect University Based on Your Scores`
  String get findYourPerfectUniversityBasedOnYourScores {
    return Intl.message(
      'Find Your Perfect University Based on Your Scores',
      name: 'findYourPerfectUniversityBasedOnYourScores',
      desc: '',
      args: [],
    );
  }

  /// `Find by IELTS \n Score only`
  String get findByIELTSScore {
    return Intl.message(
      'Find by IELTS \n Score only',
      name: 'findByIELTSScore',
      desc: '',
      args: [],
    );
  }

  /// `Find by TOEFL \n Score only`
  String get findByTOEFLScore {
    return Intl.message(
      'Find by TOEFL \n Score only',
      name: 'findByTOEFLScore',
      desc: '',
      args: [],
    );
  }

  /// `Find by GRE \n Score only`
  String get findByGREScore {
    return Intl.message(
      'Find by GRE \n Score only',
      name: 'findByGREScore',
      desc: '',
      args: [],
    );
  }

  /// `Find by GMAT \n Score only`
  String get findByGMATScore {
    return Intl.message(
      'Find by GMAT \n Score only',
      name: 'findByGMATScore',
      desc: '',
      args: [],
    );
  }

  /// `Compare Scores`
  String get compareScores {
    return Intl.message(
      'Compare Scores',
      name: 'compareScores',
      desc: '',
      args: [],
    );
  }

  /// `Find Top\nUniversities`
  String get findTopUniversities {
    return Intl.message(
      'Find Top\nUniversities',
      name: 'findTopUniversities',
      desc: '',
      args: [],
    );
  }

  /// `Wishlisted \nUniversities`
  String get wishlistedUniversities {
    return Intl.message(
      'Wishlisted \nUniversities',
      name: 'wishlistedUniversities',
      desc: '',
      args: [],
    );
  }

  /// `User`
  String get user {
    return Intl.message(
      'User',
      name: 'user',
      desc: '',
      args: [],
    );
  }

  /// `History`
  String get history {
    return Intl.message(
      'History',
      name: 'history',
      desc: '',
      args: [],
    );
  }

  /// `Done`
  String get done {
    return Intl.message(
      'Done',
      name: 'done',
      desc: '',
      args: [],
    );
  }

  /// `Next`
  String get next {
    return Intl.message(
      'Next',
      name: 'next',
      desc: '',
      args: [],
    );
  }

  /// `8.0 - 9.0`
  String get eight_to_nine {
    return Intl.message(
      '8.0 - 9.0',
      name: 'eight_to_nine',
      desc: '',
      args: [],
    );
  }

  /// `7.0 - 7.9`
  String get seven_to_eight {
    return Intl.message(
      '7.0 - 7.9',
      name: 'seven_to_eight',
      desc: '',
      args: [],
    );
  }

  /// `6.0 - 6.9`
  String get six_to_seven {
    return Intl.message(
      '6.0 - 6.9',
      name: 'six_to_seven',
      desc: '',
      args: [],
    );
  }

  /// `6.0 or below`
  String get six_or_below {
    return Intl.message(
      '6.0 or below',
      name: 'six_or_below',
      desc: '',
      args: [],
    );
  }

  /// `320 - 340`
  String get three_twenty_to_three_forty {
    return Intl.message(
      '320 - 340',
      name: 'three_twenty_to_three_forty',
      desc: '',
      args: [],
    );
  }

  /// `300 - 319`
  String get three_hundred_to_three_hundred_nineteen {
    return Intl.message(
      '300 - 319',
      name: 'three_hundred_to_three_hundred_nineteen',
      desc: '',
      args: [],
    );
  }

  /// `260 - 300`
  String get two_sixty_to_three_hundred {
    return Intl.message(
      '260 - 300',
      name: 'two_sixty_to_three_hundred',
      desc: '',
      args: [],
    );
  }

  /// `700 - 800`
  String get seven_hundred_to_hundred {
    return Intl.message(
      '700 - 800',
      name: 'seven_hundred_to_hundred',
      desc: '',
      args: [],
    );
  }

  /// `600 - 700`
  String get six_hundered_to_seven_hundred {
    return Intl.message(
      '600 - 700',
      name: 'six_hundered_to_seven_hundred',
      desc: '',
      args: [],
    );
  }

  /// `450 - 600`
  String get four_hundred_fifty_to_six_hundred {
    return Intl.message(
      '450 - 600',
      name: 'four_hundred_fifty_to_six_hundred',
      desc: '',
      args: [],
    );
  }

  /// `100 - 120`
  String get hundred_to_one_twenty {
    return Intl.message(
      '100 - 120',
      name: 'hundred_to_one_twenty',
      desc: '',
      args: [],
    );
  }

  /// `80 - 100`
  String get eighty_to_hundred {
    return Intl.message(
      '80 - 100',
      name: 'eighty_to_hundred',
      desc: '',
      args: [],
    );
  }

  /// `60 - 80`
  String get sixty_to_eighty {
    return Intl.message(
      '60 - 80',
      name: 'sixty_to_eighty',
      desc: '',
      args: [],
    );
  }

  /// `Hello`
  String get hello {
    return Intl.message(
      'Hello',
      name: 'hello',
      desc: '',
      args: [],
    );
  }

  /// `Home`
  String get home {
    return Intl.message(
      'Home',
      name: 'home',
      desc: '',
      args: [],
    );
  }

  /// `Account`
  String get account {
    return Intl.message(
      'Account',
      name: 'account',
      desc: '',
      args: [],
    );
  }

  /// `Features`
  String get features {
    return Intl.message(
      'Features',
      name: 'features',
      desc: '',
      args: [],
    );
  }

  /// `Settings`
  String get settings {
    return Intl.message(
      'Settings',
      name: 'settings',
      desc: '',
      args: [],
    );
  }

  /// `Help`
  String get help {
    return Intl.message(
      'Help',
      name: 'help',
      desc: '',
      args: [],
    );
  }

  /// `What is your preferred level of study?`
  String get whatIsYourPreferredLevelOfStudy {
    return Intl.message(
      'What is your preferred level of study?',
      name: 'whatIsYourPreferredLevelOfStudy',
      desc: '',
      args: [],
    );
  }

  /// `Undergraduate`
  String get undergraduate {
    return Intl.message(
      'Undergraduate',
      name: 'undergraduate',
      desc: '',
      args: [],
    );
  }

  /// `Graduate`
  String get graduate {
    return Intl.message(
      'Graduate',
      name: 'graduate',
      desc: '',
      args: [],
    );
  }

  /// `PhD`
  String get phd {
    return Intl.message(
      'PhD',
      name: 'phd',
      desc: '',
      args: [],
    );
  }

  /// `Which countries do you prefer to study in?`
  String get whichCountriesDoYouPreferToStudyIn {
    return Intl.message(
      'Which countries do you prefer to study in?',
      name: 'whichCountriesDoYouPreferToStudyIn',
      desc: '',
      args: [],
    );
  }

  /// `USA`
  String get usa {
    return Intl.message(
      'USA',
      name: 'usa',
      desc: '',
      args: [],
    );
  }

  /// `Delete`
  String get delete {
    return Intl.message(
      'Delete',
      name: 'delete',
      desc: '',
      args: [],
    );
  }

  /// `UK`
  String get uk {
    return Intl.message(
      'UK',
      name: 'uk',
      desc: '',
      args: [],
    );
  }

  /// `Australia`
  String get australia {
    return Intl.message(
      'Australia',
      name: 'australia',
      desc: '',
      args: [],
    );
  }

  /// `Germany`
  String get germany {
    return Intl.message(
      'Germany',
      name: 'germany',
      desc: '',
      args: [],
    );
  }

  /// `Login failed. Please try again.`
  String get loginFailed {
    return Intl.message(
      'Login failed. Please try again.',
      name: 'loginFailed',
      desc: '',
      args: [],
    );
  }

  /// `What is your intended major or program of interest?`
  String get whatIsYourIntendedMajorOrProgramOfInterest {
    return Intl.message(
      'What is your intended major or program of interest?',
      name: 'whatIsYourIntendedMajorOrProgramOfInterest',
      desc: '',
      args: [],
    );
  }

  /// `What is your approximate budget for tuition and living expenses?`
  String get whatIsYourApproximateBudgetForTuitionAndLivingExpenses {
    return Intl.message(
      'What is your approximate budget for tuition and living expenses?',
      name: 'whatIsYourApproximateBudgetForTuitionAndLivingExpenses',
      desc: '',
      args: [],
    );
  }

  /// `What are your IELTS score?`
  String get whatAreYourIELTSScore {
    return Intl.message(
      'What are your IELTS score?',
      name: 'whatAreYourIELTSScore',
      desc: '',
      args: [],
    );
  }

  /// `Type your score`
  String get typeYourScore {
    return Intl.message(
      'Type your score',
      name: 'typeYourScore',
      desc: '',
      args: [],
    );
  }

  /// `Yes`
  String get yes {
    return Intl.message(
      'Yes',
      name: 'yes',
      desc: '',
      args: [],
    );
  }

  /// `No`
  String get no {
    return Intl.message(
      'No',
      name: 'no',
      desc: '',
      args: [],
    );
  }

  /// `What is your GPA or percentage score from previous studies?`
  String get whatIsYourGPAOrPercentageScoreFromPreviousStudies {
    return Intl.message(
      'What is your GPA or percentage score from previous studies?',
      name: 'whatIsYourGPAOrPercentageScoreFromPreviousStudies',
      desc: '',
      args: [],
    );
  }

  /// `Based on your scores, here are universities tailored just for you. Start exploring your future today!`
  String get basedOnYour {
    return Intl.message(
      'Based on your scores, here are universities tailored just for you. Start exploring your future today!',
      name: 'basedOnYour',
      desc: '',
      args: [],
    );
  }

  /// `What are your TOEFL scores?`
  String get whatAreYourTOEFLScores {
    return Intl.message(
      'What are your TOEFL scores?',
      name: 'whatAreYourTOEFLScores',
      desc: '',
      args: [],
    );
  }

  /// `Input your TOEFL score`
  String get inputYourTOEFLScore {
    return Intl.message(
      'Input your TOEFL score',
      name: 'inputYourTOEFLScore',
      desc: '',
      args: [],
    );
  }

  /// `Input your IELTS score`
  String get inputYourIELTSScore {
    return Intl.message(
      'Input your IELTS score',
      name: 'inputYourIELTSScore',
      desc: '',
      args: [],
    );
  }

  /// `Input your GMAT score`
  String get inputYourGMATScore {
    return Intl.message(
      'Input your GMAT score',
      name: 'inputYourGMATScore',
      desc: '',
      args: [],
    );
  }

  /// `Input your GRE score`
  String get inputYourGREScore {
    return Intl.message(
      'Input your GRE score',
      name: 'inputYourGREScore',
      desc: '',
      args: [],
    );
  }

  /// `Input your preferred location`
  String get inputYourPreferredLocation {
    return Intl.message(
      'Input your preferred location',
      name: 'inputYourPreferredLocation',
      desc: '',
      args: [],
    );
  }

  /// `What are your GRE scores?`
  String get whatAreYourGREScores {
    return Intl.message(
      'What are your GRE scores?',
      name: 'whatAreYourGREScores',
      desc: '',
      args: [],
    );
  }

  /// `What are your GMAT scores?`
  String get whatAreYourGMATScores {
    return Intl.message(
      'What are your GMAT scores?',
      name: 'whatAreYourGMATScores',
      desc: '',
      args: [],
    );
  }

  /// `Have you given GRE before?`
  String get haveYouGivenGREBefore {
    return Intl.message(
      'Have you given GRE before?',
      name: 'haveYouGivenGREBefore',
      desc: '',
      args: [],
    );
  }

  /// `Have you given GMAT before?`
  String get haveYouGivenGMATBefore {
    return Intl.message(
      'Have you given GMAT before?',
      name: 'haveYouGivenGMATBefore',
      desc: '',
      args: [],
    );
  }

  /// `Have you given TOEFL before?`
  String get haveYouGivenTOEFLBefore {
    return Intl.message(
      'Have you given TOEFL before?',
      name: 'haveYouGivenTOEFLBefore',
      desc: '',
      args: [],
    );
  }

  /// `Have you given IELTS before?`
  String get haveYouGivenIELTSBefore {
    return Intl.message(
      'Have you given IELTS before?',
      name: 'haveYouGivenIELTSBefore',
      desc: '',
      args: [],
    );
  }

  /// `FIND YOUR FAVOURITE UNIVERSITY`
  String get findYourFavouriteUniversity {
    return Intl.message(
      'FIND YOUR FAVOURITE UNIVERSITY',
      name: 'findYourFavouriteUniversity',
      desc: '',
      args: [],
    );
  }

  /// `Share your scores and preferences, and we will match you with universities that fit your goals. Your dream starts here!`
  String get shareYourScores {
    return Intl.message(
      'Share your scores and preferences, and we will match you with universities that fit your goals. Your dream starts here!',
      name: 'shareYourScores',
      desc: '',
      args: [],
    );
  }

  /// `Get Started`
  String get getStarted {
    return Intl.message(
      'Get Started',
      name: 'getStarted',
      desc: '',
      args: [],
    );
  }

  /// `Country Preferences`
  String get countryPreferences {
    return Intl.message(
      'Country Preferences',
      name: 'countryPreferences',
      desc: '',
      args: [],
    );
  }

  /// `Preferred Study Level`
  String get preferredStudyLevel {
    return Intl.message(
      'Preferred Study Level',
      name: 'preferredStudyLevel',
      desc: '',
      args: [],
    );
  }

  /// `Field of Study`
  String get fieldOfStudy {
    return Intl.message(
      'Field of Study',
      name: 'fieldOfStudy',
      desc: '',
      args: [],
    );
  }

  /// `Budget Range`
  String get budgetRange {
    return Intl.message(
      'Budget Range',
      name: 'budgetRange',
      desc: '',
      args: [],
    );
  }

  /// `IELTS Score`
  String get ieltsScore {
    return Intl.message(
      'IELTS Score',
      name: 'ieltsScore',
      desc: '',
      args: [],
    );
  }

  /// `GPA`
  String get gpa {
    return Intl.message(
      'GPA',
      name: 'gpa',
      desc: '',
      args: [],
    );
  }

  /// `Register Account`
  String get registerAccount {
    return Intl.message(
      'Register Account',
      name: 'registerAccount',
      desc: '',
      args: [],
    );
  }

  /// `First Name`
  String get firstName {
    return Intl.message(
      'First Name',
      name: 'firstName',
      desc: '',
      args: [],
    );
  }

  /// `Last Name`
  String get lastName {
    return Intl.message(
      'Last Name',
      name: 'lastName',
      desc: '',
      args: [],
    );
  }

  /// `Welcome Message`
  String get welcomeMessage {
    return Intl.message(
      'Welcome Message',
      name: 'welcomeMessage',
      desc: '',
      args: [],
    );
  }

  /// `Library Pulse`
  String get libraryPulse {
    return Intl.message(
      'Library Pulse',
      name: 'libraryPulse',
      desc: '',
      args: [],
    );
  }

  /// `What readers nearby want right now`
  String get whatReadersWant {
    return Intl.message(
      'What readers nearby want right now',
      name: 'whatReadersWant',
      desc: '',
      args: [],
    );
  }

  /// `Trending Genres`
  String get trendingGenres {
    return Intl.message(
      'Trending Genres',
      name: 'trendingGenres',
      desc: '',
      args: [],
    );
  }

  /// `Books to Stock`
  String get booksToStock {
    return Intl.message(
      'Books to Stock',
      name: 'booksToStock',
      desc: '',
      args: [],
    );
  }

  /// `Based on Collected Reader Data`
  String get basedOnCollectedReaderData {
    return Intl.message(
      'Based on Collected Reader Data',
      name: 'basedOnCollectedReaderData',
      desc: '',
      args: [],
    );
  }

  /// `The Name of the Wind`
  String get theNameOfTheWind {
    return Intl.message(
      'The Name of the Wind',
      name: 'theNameOfTheWind',
      desc: '',
      args: [],
    );
  }

  /// `Patrick Rothfus`
  String get patrickRothfus {
    return Intl.message(
      'Patrick Rothfus',
      name: 'patrickRothfus',
      desc: '',
      args: [],
    );
  }

  /// `Fantasy`
  String get fantasy {
    return Intl.message(
      'Fantasy',
      name: 'fantasy',
      desc: '',
      args: [],
    );
  }

  /// `Profile`
  String get profile {
    return Intl.message(
      'Profile',
      name: 'profile',
      desc: '',
      args: [],
    );
  }

  /// `Log out`
  String get logOut {
    return Intl.message(
      'Log out',
      name: 'logOut',
      desc: '',
      args: [],
    );
  }

  /// `Add Book`
  String get addBook {
    return Intl.message(
      'Add Book',
      name: 'addBook',
      desc: '',
      args: [],
    );
  }

  /// `View Database`
  String get viewDatabase {
    return Intl.message(
      'View Database',
      name: 'viewDatabase',
      desc: '',
      args: [],
    );
  }

  /// `Book Details`
  String get bookDetails {
    return Intl.message(
      'Book Details',
      name: 'bookDetails',
      desc: '',
      args: [],
    );
  }

  /// `Why It's recommended`
  String get whyItIsRecommended {
    return Intl.message(
      'Why It\'s recommended',
      name: 'whyItIsRecommended',
      desc: '',
      args: [],
    );
  }

  /// `This fantasy epic has surged in popularity. especially among readers who enjoy immersive world-building and richly developed characters. Recent activity shows a spike in holds and requests for this title.`
  String get bookDescription {
    return Intl.message(
      'This fantasy epic has surged in popularity. especially among readers who enjoy immersive world-building and richly developed characters. Recent activity shows a spike in holds and requests for this title.',
      name: 'bookDescription',
      desc: '',
      args: [],
    );
  }

  /// `Close`
  String get close {
    return Intl.message(
      'Close',
      name: 'close',
      desc: '',
      args: [],
    );
  }

  /// `Already in DB`
  String get alreadyInDb {
    return Intl.message(
      'Already in DB',
      name: 'alreadyInDb',
      desc: '',
      args: [],
    );
  }

  /// `Add`
  String get add {
    return Intl.message(
      'Add',
      name: 'add',
      desc: '',
      args: [],
    );
  }

  /// `Browse the list of books currently in your database`
  String get browseTheListOfBooksCurrentlyInYourDatabase {
    return Intl.message(
      'Browse the list of books currently in your database',
      name: 'browseTheListOfBooksCurrentlyInYourDatabase',
      desc: '',
      args: [],
    );
  }

  /// `Library Database`
  String get libraryDatabase {
    return Intl.message(
      'Library Database',
      name: 'libraryDatabase',
      desc: '',
      args: [],
    );
  }

  /// `All Genres`
  String get allGenres {
    return Intl.message(
      'All Genres',
      name: 'allGenres',
      desc: '',
      args: [],
    );
  }

  /// `Search`
  String get search {
    return Intl.message(
      'Search',
      name: 'search',
      desc: '',
      args: [],
    );
  }

  /// `In Stock`
  String get inStock {
    return Intl.message(
      'In Stock',
      name: 'inStock',
      desc: '',
      args: [],
    );
  }

  /// `Delete Books`
  String get deleteBooks {
    return Intl.message(
      'Delete Books',
      name: 'deleteBooks',
      desc: '',
      args: [],
    );
  }

  /// `Profile Information`
  String get profileInformation {
    return Intl.message(
      'Profile Information',
      name: 'profileInformation',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to log out?`
  String get areYouSureYouWantToLogOut {
    return Intl.message(
      'Are you sure you want to log out?',
      name: 'areYouSureYouWantToLogOut',
      desc: '',
      args: [],
    );
  }

  /// `Any unsaved changes will be lost.`
  String get anyUnsavedChangesWillBeLost {
    return Intl.message(
      'Any unsaved changes will be lost.',
      name: 'anyUnsavedChangesWillBeLost',
      desc: '',
      args: [],
    );
  }

  /// `Edit Profile`
  String get editProfile {
    return Intl.message(
      'Edit Profile',
      name: 'editProfile',
      desc: '',
      args: [],
    );
  }

  /// `Change Password`
  String get changePassword {
    return Intl.message(
      'Change Password',
      name: 'changePassword',
      desc: '',
      args: [],
    );
  }

  /// `Title`
  String get title {
    return Intl.message(
      'Title',
      name: 'title',
      desc: '',
      args: [],
    );
  }

  /// `Author`
  String get author {
    return Intl.message(
      'Author',
      name: 'author',
      desc: '',
      args: [],
    );
  }

  /// `Genre`
  String get genre {
    return Intl.message(
      'Genre',
      name: 'genre',
      desc: '',
      args: [],
    );
  }

  /// `Add Genre`
  String get addGenre {
    return Intl.message(
      'Add Genre',
      name: 'addGenre',
      desc: '',
      args: [],
    );
  }

  /// `Save`
  String get save {
    return Intl.message(
      'Save',
      name: 'save',
      desc: '',
      args: [],
    );
  }

  /// `Cancel`
  String get cancel {
    return Intl.message(
      'Cancel',
      name: 'cancel',
      desc: '',
      args: [],
    );
  }

  /// `Location`
  String get location {
    return Intl.message(
      'Location',
      name: 'location',
      desc: '',
      args: [],
    );
  }

  /// `Enter Book Title`
  String get enterBookTitle {
    return Intl.message(
      'Enter Book Title',
      name: 'enterBookTitle',
      desc: '',
      args: [],
    );
  }

  /// `Enter Author's Name`
  String get enterAuthorsName {
    return Intl.message(
      'Enter Author\'s Name',
      name: 'enterAuthorsName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid email`
  String get pleaseEnterValidEmail {
    return Intl.message(
      'Please enter valid email',
      name: 'pleaseEnterValidEmail',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid name`
  String get pleaseEnterValidName {
    return Intl.message(
      'Please enter valid name',
      name: 'pleaseEnterValidName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid DOB`
  String get pleaseEnterValidDOB {
    return Intl.message(
      'Please enter valid DOB',
      name: 'pleaseEnterValidDOB',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid phone number`
  String get pleaseEnterValidPhoneNumber {
    return Intl.message(
      'Please enter valid phone number',
      name: 'pleaseEnterValidPhoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `Please Enter Valid Location`
  String get pleaseEnterValidLocation {
    return Intl.message(
      'Please Enter Valid Location',
      name: 'pleaseEnterValidLocation',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid Password`
  String get pleaseEnterValidPassword {
    return Intl.message(
      'Please enter valid Password',
      name: 'pleaseEnterValidPassword',
      desc: '',
      args: [],
    );
  }

  /// `Password and confirm password do not match`
  String get passwordAndConfirmPasswordDoNotMatch {
    return Intl.message(
      'Password and confirm password do not match',
      name: 'passwordAndConfirmPasswordDoNotMatch',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'en', countryCode: 'US'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
