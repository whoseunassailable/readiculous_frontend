class AppFontSize {
  static const double xxxs = 1 / 80;
  static const double xxs = 1 / 60;
  static const double xs = 1 / 40;
  static const double s = 1 / 35;
  static const double m = 1 / 30;
  static const double ml = 1 / 25;
  static const double l = 1 / 22.5;
  static const double xl = 1 / 20;
  static const double xxl = 1 / 18;
  static const double xxxl = 1 / 14;
  static const double xxxxl = 1 / 12;
  static const double xxxxxl = 1 / 10;
}
